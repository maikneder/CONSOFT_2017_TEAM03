-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: sgc
-- ------------------------------------------------------
-- Server version	5.6.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conferencia`
--

DROP TABLE IF EXISTS `conferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conferencia` (
  `idconferencia` int(11) NOT NULL DEFAULT '0',
  `nome` varchar(45) DEFAULT NULL,
  `subtitulo` varchar(45) DEFAULT NULL,
  `nome_abr` varchar(45) DEFAULT NULL,
  `subtitulo_sec` varchar(45) DEFAULT NULL,
  `pag_web` varchar(45) DEFAULT NULL,
  `organizador` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `remetente_email` varchar(45) DEFAULT NULL,
  `email_conf` varchar(45) DEFAULT NULL,
  `end_rem` varchar(45) DEFAULT NULL,
  `conferenciacol` varchar(45) DEFAULT NULL,
  `arq_sup` varchar(45) DEFAULT NULL,
  `moeda` varchar(45) DEFAULT NULL,
  `idevento` int(11) DEFAULT NULL,
  `idsessao` int(11) DEFAULT NULL,
  `idusuario` int(11) DEFAULT NULL,
  `idcategoriapreco` int(11) DEFAULT NULL,
  `idfase` int(11) DEFAULT NULL,
  `idtopico` int(11) DEFAULT NULL,
  `idsubmissao` int(11) DEFAULT NULL,
  PRIMARY KEY (`idconferencia`),
  KEY `id_evento_idx1` (`idevento`),
  KEY `id_submissao_idx` (`idsubmissao`),
  KEY `id_usuario_idx` (`idusuario`),
  KEY `id_sessao_idx` (`idsessao`),
  KEY `id_topico_idx` (`idtopico`),
  KEY `id_fase_idx` (`idfase`),
  KEY `id_categoria_preco_idx` (`idcategoriapreco`),
  CONSTRAINT `id_categoria_preco` FOREIGN KEY (`idcategoriapreco`) REFERENCES `categoria_preco` (`idcategoria_preco`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_evento` FOREIGN KEY (`idevento`) REFERENCES `evento` (`id_evento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_fase` FOREIGN KEY (`idfase`) REFERENCES `fase` (`idfase`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_sessao` FOREIGN KEY (`idsessao`) REFERENCES `sessao` (`id_sessao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_submissao` FOREIGN KEY (`idsubmissao`) REFERENCES `submissao` (`id_submissao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_topico` FOREIGN KEY (`idtopico`) REFERENCES `topico` (`idtopico`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conferencia`
--

LOCK TABLES `conferencia` WRITE;
/*!40000 ALTER TABLE `conferencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `conferencia` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-26 22:23:46
